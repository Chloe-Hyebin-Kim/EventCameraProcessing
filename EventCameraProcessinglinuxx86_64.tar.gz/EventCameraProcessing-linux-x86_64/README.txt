EventCameraProcessing - Linux x86_64 배포판 (직접 빌드 불필요)
================================================================

Metavision SDK(OpenEB) 5.2.0 소스 빌드 결과와 EventProcessing.DiagQt /
EventProcessing.Console 실행 파일을 미리 빌드해서 묶은 패키지입니다.
받는 사람은 OpenEB를 직접 빌드할 필요 없이 아래 절차만 따르면 됩니다.

빌드 환경: Ubuntu 24.04 (noble), x86_64, glibc 2.39
-> 실행 대상 머신도 Ubuntu 24.04 계열(또는 호환 glibc 버전 이상)이어야 합니다.
   많이 다른 배포판/버전이면 아래 "문제 해결" 참고.

1) 필요 패키지 설치 (최초 1회, sudo 필요)
------------------------------------------
   sudo apt update
   sudo apt install libopencv-dev qt6-base-dev libusb-1.0-0

   (OpenCV/Qt는 리포 README와 동일한 표준 apt 패키지입니다. 이 패키지들은
    apt로 흔히 설치되어 있을 가능성이 높아 배포 용량을 줄이려고 tarball에는
    포함하지 않았습니다. Metavision SDK 관련 라이브러리만 lib/, hal_plugins/
    에 동봉했습니다.)

2) 압축 해제 후 실행
------------------------------------------
   tar xzf EventCameraProcessing-linux-x86_64.tar.gz
   cd EventCameraProcessing-linux-x86_64
   ./run-diagqt.sh                      # GUI (Live/RAW Diagnostic Viewer)
   ./run-console.sh input.csv output 10000 30   # CLI 배치 처리

   실행 파일을 직접 실행하지 말고 반드시 run-diagqt.sh / run-console.sh를
   통해 실행하세요 (동봉된 Metavision SDK 라이브러리 경로를 잡아줍니다).

3) EVK4 HD 카메라를 USB로 연결해서 쓸 경우 (선택)
------------------------------------------
   udev 규칙을 설치해야 일반 사용자 권한으로 카메라 장치에 접근할 수 있습니다:

   sudo cp udev-rules/*.rules /etc/udev/rules.d/
   sudo udevadm control --reload-rules
   sudo udevadm trigger

   (카메라 없이 CSV/RAW 파일만 볼 거면 이 단계는 생략 가능)

폴더 구성
------------------------------------------
   EventProcessing.DiagQt      실행 파일 (GUI)
   EventProcessing.Console     실행 파일 (CLI)
   run-diagqt.sh                GUI 실행 래퍼 (LD_LIBRARY_PATH 설정)
   run-console.sh                CLI 실행 래퍼
   lib/                         Metavision SDK 런타임 라이브러리 (apt로 설치 불가, 동봉)
   hal_plugins/                 Metavision HAL 카메라 플러그인
   udev-rules/                  Prophesee 카메라 USB 권한 규칙

문제 해결
------------------------------------------
- "error while loading shared libraries: libQt6Widgets.so.6" 등 OpenCV/Qt 관련
  에러 -> 1)의 apt install을 아직 안 했거나 배포판에 해당 패키지가 없는 경우.
  대상 머신에서 `sudo apt install libopencv-dev qt6-base-dev`를 실행하세요.
- glibc 버전이 너무 오래된 배포판(Ubuntu 20.04 이하 등)에서는 이 바이너리가
  아예 안 돌아갈 수 있습니다. 이 경우는 바이너리 배포 대신 그 머신에서
  `./scripts/setup-linux-openeb.sh` 로 직접 소스 빌드해야 합니다
  (리포 루트 README.md 참고).
- 카메라가 인식되지 않으면 udev 규칙 설치(3번) 여부와 USB 연결을 확인하세요.
