#!/usr/bin/env bash
# EventProcessing.Console 실행 스크립트 (인자 그대로 전달).
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export LD_LIBRARY_PATH="$DIR/lib:${LD_LIBRARY_PATH:-}"
export MV_HAL_PLUGIN_PATH="$DIR/hal_plugins"
exec "$DIR/EventProcessing.Console" "$@"
