#!/usr/bin/env bash
# EventProcessing.DiagQt 실행 스크립트.
# 같은 폴더의 lib/ (Metavision SDK 런타임)를 LD_LIBRARY_PATH에 추가하고,
# hal_plugins/ 를 MV_HAL_PLUGIN_PATH로 지정한 뒤 실행 파일을 구동한다.
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export LD_LIBRARY_PATH="$DIR/lib:${LD_LIBRARY_PATH:-}"
export MV_HAL_PLUGIN_PATH="$DIR/hal_plugins"
exec "$DIR/EventProcessing.DiagQt" "$@"
